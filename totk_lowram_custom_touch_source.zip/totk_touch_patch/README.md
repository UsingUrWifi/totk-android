# TotK Low RAM — configurable touchscreen port (source candidate)

Base: GTomasel/totk-android-low-ram, commit `efe6e56711a8d4bfe56b041ec5ac2060c127b531` (2026-11-23).
Overlay donor: UsingUrWifi/totk-android, branch `exp/totk-upstream-touch`.

This bundle implements independent Hold/Toggle/Timed press/Turbo modes on all 16 native button bits; four named, independently configurable simultaneous-input shortcuts (M1–M4); three persisted layout profiles; button positions and individual sizes; analog sensitivity/dead zone and stick positions; opacity, global size and haptics. ZR defaults to Toggle; other buttons default to Hold except migrated ZL preference. Timed and turbo modes share a configurable 80–5000 ms setting (turbo is a full cycle, 50% duty). A combo outputs its selected buttons simultaneously; it is not a scripted sequence. Shortcuts do not toggle the independent latches of their constituent buttons. A second tap releases a toggled trigger unless another active control is also asserting the same button. All latches and timers are cleared on pause, detach, focus loss, configuration change, or opening settings. Stick sizes share global scale. The existing old overlay design is retained, except the D-pad directions are drawn independently to support positioning. The old fork-specific performance-monitor panel is intentionally omitted; Low RAM's native rendering, memory, and frame rate settings are preserved.

## Apply on a Linux build machine with Git, Python 3.12+, and JDK 17+

From the extracted bundle directory:

```sh
git clone https://github.com/GTomasel/totk-android-low-ram.git lowram
git -C lowram checkout --detach efe6e56711a8d4bfe56b041ec5ac2060c127b531
git -C lowram switch -c exp/totk-lowram-custom-touch
git clone --branch exp/totk-upstream-touch --single-branch https://github.com/UsingUrWifi/totk-android.git old-touch
python3 apply.py lowram old-touch --check
python3 apply.py lowram old-touch
git -C lowram diff --check
git -C lowram status --short
```

The script validates the base revision, clean worktree and expected source anchors before writing any of the six files. If it aborts, do not weaken its guards: inspect the source mismatch. It only modifies local files, not GitHub. No game files or signing keys are included. Keep your original installation and saves backed up.

## Desktop regression test

```sh
mkdir -p test-classes
javac -d test-classes TouchBindings.java TouchBindingsProbe.java
java -cp test-classes com.aure.totk.TouchBindingsProbe
```

## Android build (requires existing toolchain and signing material)

Use the fork's documented prerequisites: Android SDK/NDK r28, pinned Turnip driver, translator/.NET 10, and your existing release signing key. For a side-by-side test install, use a distinct package ID and launcher label (the upstream build script supports both). Do not uninstall the original game or overwrite its save folder. A new package may require separate game setup using your legally obtained game files.

```sh
cd lowram
python3 games/totk/android/build_release.py \
  --ndk "$ANDROID_NDK_HOME" --turnip "$TURNIP_SO" --key "$SIGNING_KEY" \
  --package com.aure.totk.lowram.touch --label 'TotK Low RAM Touch' \
  --out "$PWD/totk-lowram-touch.apk"
```

Set TURNIP_SO and SIGNING_KEY to the real local paths; keep credentials private. If the build requires additional dependencies, consult the fork README. The APK is not included in this source bundle.

## Device acceptance (not yet run)

1. Check unmodified Low RAM startup and establish performance baseline; ensure game reaches playable state.
2. Launch separate touch build, confirm overlay visible and PAD opens its menu. Ensure hardware controller still works.
3. Tap ZR, lift finger, aim with right analog, then tap ZR again. Test ZL independently and both held at once.
4. Test M1–M4 with simultaneous button inputs, both Hold and Toggle, and overlapping normal controls. Verify no accidental latch changes.
5. Test timed press release without further touch; verify turbo stops on finger release.
6. Pause, background, rotate/fold/unfold, open settings; all controls must return neutral without ghost inputs.
7. Change positions/sizes, profile and analog settings; close/reopen game, verify persistence and sensible layout.
8. Compare identical scene, graphics settings and thermal state to the unmodified fork; investigate any regression before daily use.

## Verification status

The included pure Java engine/probe compiled and passed in the authoring environment. Python patch script syntax checked. Actual patch application, Android build, JNI linkage, signing, installation, and Fold5 runtime behavior have NOT been verified: the authoring environment has no GitHub network access, and the connected GitHub API returned 403 when creating the requested branch. No remote changes or APK were produced.
