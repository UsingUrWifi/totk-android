package com.aure.totk;
final class TouchBindingsProbe {
 static long b(int i){return 1L<<i;}
 static void eq(long a,long e){if(a!=e)throw new AssertionError(a+" != "+e);}
 public static void main(String[] args){
  TouchBindings t=new TouchBindings();t.configure(8,1,250,b(8));t.configure(9,1,250,b(9));
  eq(t.apply(b(9),0),b(9));eq(t.apply(0,1),b(9));eq(t.apply(b(8),2),b(8)|b(9));eq(t.apply(0,3),b(8)|b(9));eq(t.apply(b(9),4),b(8));eq(t.apply(0,5),b(8));
  t.configure(16,0,250,b(8)|b(9)|b(0));eq(t.apply(b(16),10),b(8)|b(9)|b(0));eq(t.apply(0,11),0);
  t.configure(16,1,250,b(8)|b(9));eq(t.apply(b(16),12),b(8)|b(9));eq(t.apply(0,13),b(8)|b(9));eq(t.apply(b(16),14),0);
  t.configure(17,2,250,b(1));eq(t.apply(b(17),100),b(1));eq(t.apply(0,200),b(1));eq(t.nextDelay(200),150);eq(t.apply(0,350),0);eq(t.nextDelay(350),-1);
  t.configure(18,3,100,b(2));eq(t.apply(b(18),500),b(2));eq(t.nextDelay(500),50);eq(t.apply(b(18),550),0);eq(t.apply(b(18),600),b(2));eq(t.apply(0,610),0);eq(t.nextDelay(610),-1);
  t.configure(19,1,250,b(9));eq(t.apply(b(19),700),b(9));eq(t.apply(0,701),b(9));t.reset();eq(t.apply(0,702),0);
  t.configure(16,0,250,b(9));eq(t.apply(b(16)|b(9),800),b(9));eq(t.apply(b(9),801),b(9));eq(t.apply(0,802),b(9));eq(t.apply(b(9),803),0);
  System.out.println("TouchBindings: all assertions passed");
 }
}
