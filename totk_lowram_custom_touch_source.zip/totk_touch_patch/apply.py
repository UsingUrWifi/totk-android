#!/usr/bin/env python3
"""Port the old overlay onto the pinned Low RAM checkout; abort on unexpected source."""
import argparse, subprocess, pathlib, re, sys
HERE=pathlib.Path(__file__).resolve().parent
PIN='efe6e56711a8d4bfe56b041ec5ac2060c127b531'
JAVA='games/totk/android/java/com/aure/totk/'
RUNTIME='games/totk/runtime/'
def git(p,*args): return subprocess.check_output(['git','-C',str(p),*args],text=True).strip()
def one(s,a,b):
    if s.count(a)!=1: raise ValueError(f'Expected one occurrence of {a[:100]!r}; found {s.count(a)}')
    return s.replace(a,b,1)
def section(s,a,b,repl):
    i=s.index(a);j=s.index(b,i);return s[:i]+repl+s[j:]
def main():
    p=argparse.ArgumentParser();p.add_argument('lowram',type=pathlib.Path);p.add_argument('old',type=pathlib.Path);p.add_argument('--check',action='store_true');a=p.parse_args()
    root=a.lowram.resolve();old=a.old.resolve()
    if git(root,'rev-parse','HEAD')!=PIN: raise ValueError('Low RAM checkout must be at '+PIN)
    if git(root,'status','--porcelain'): raise ValueError('Use a clean Low RAM worktree')
    def read(rel):return (root/rel).read_text()
    def previous(rel):return (old/rel).read_text()
    changes={}
    v=previous(JAVA+'TouchControlsView.java')
    # Preserve original rendering, pointer tracking and styling; use generalized bindings.
    v=one(v,'import android.app.AlertDialog;','import android.app.AlertDialog;\nimport android.os.SystemClock;\nimport android.widget.EditText;\nimport android.widget.LinearLayout;\nimport android.widget.TextView;\nimport android.widget.Spinner;\nimport android.widget.ArrayAdapter;\nimport android.widget.SeekBar;\nimport android.widget.ScrollView;')
    v=one(v,'private final SharedPreferences prefs;','private SharedPreferences prefs;\n    private int profile;')
    v=one(v,'private final TouchPerfDiagnostics diagnostics;\n    private boolean comboEnabled;\n    private float comboX, comboY, comboRadius;','''private final boolean[] comboEnabled = new boolean[4];
    private final String[] comboLabels = new String[4];
    private final float[] comboX = new float[4], comboY = new float[4], comboRadius = new float[4];
    private float sensitivity = 1f, deadzone = .10f;
    private final Runnable timer = this::updateNative;''')
    v=one(v,'final float originX, originY;','final float originX, originY;\n        int slot = -1;')
    v=section(v,'        prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE);','        setClickable(true);','''        profile = Math.max(0,Math.min(2,activity.getSharedPreferences(PREFS + "_profiles", Context.MODE_PRIVATE).getInt("active", 0)));
        loadProfile();
''')
    v=one(v,'    private static float clamp(float v, float min, float max) {','''    private void loadProfile() {
        prefs = activity.getSharedPreferences(profile == 0 ? PREFS : PREFS + "_" + profile, Context.MODE_PRIVATE);
        visible = prefs.getBoolean(KEY_VISIBLE, true);
        proStyle = !STYLE_OUTLINE.equals(prefs.getString(KEY_STYLE, STYLE_PRO));
        haptics = prefs.getBoolean(KEY_HAPTICS, true);
        scale = clamp(prefs.getFloat(KEY_SCALE, 1f), .75f, 1.35f);
        opacity = clamp(prefs.getFloat(KEY_ALPHA, .46f), .20f, .85f);
        sensitivity = clamp(prefs.getFloat("sensitivity", 1f), .5f, 2f);
        deadzone = clamp(prefs.getFloat("deadzone", .10f), 0f, .35f);
        for (int i=0;i<TouchBindings.COUNT;i++) {
            int mode = prefs.getInt("mode_"+i, i==ZL && prefs.getBoolean(KEY_ZL_TOGGLE,false) || i==ZR ? TouchBindings.TOGGLE : TouchBindings.HOLD);
            long mask = i<16 ? 1L<<i : 0;
            if (i==16) { int first=prefs.getInt(KEY_COMBO_FIRST,ZL),second=prefs.getInt(KEY_COMBO_SECOND,A);
                if(first>=0 && first<16 && second>=0 && second<16) mask=(1L<<first)|(1L<<second); }
            bindings.configure(i, Math.max(0,Math.min(3,mode)), Math.max(80,Math.min(5000,prefs.getInt("duration_"+i,250))), prefs.getLong("mask_"+i,mask)&0xffffL);
            if(i>=16){int k=i-16;comboEnabled[k]=prefs.getBoolean("enabled_"+i,i==16 && prefs.getBoolean(KEY_COMBO_ENABLED,false));comboLabels[k]=prefs.getString("label_"+i,"M"+(k+1));}
        }
    }
    private static float clamp(float v, float min, float max) {''')
    v=one(v,'Button b = buttons[index]; b.x = x; b.y = y; b.radius = radius;','''Button b = buttons[index]; b.radius = radius * clamp(prefs.getFloat("size_"+index,1f),.6f,1.5f);
        b.x = clamp(prefs.getFloat("x_"+index,x/getWidth()),.04f,.96f)*getWidth();
        b.y = clamp(prefs.getFloat("y_"+index,y/getHeight()),.06f,.94f)*getHeight();''')
    v=one(v,'comboX = w * .63f; comboY = h * .59f; comboRadius = buttonRadius * .80f;','''for (int k=0;k<4;k++) {
            int slot=16+k;
            comboX[k]=w*clamp(prefs.getFloat("x_"+slot,.35f+.10f*k),.05f,.95f);
            comboY[k]=h*clamp(prefs.getFloat("y_"+slot,.59f),.08f,.92f);
            comboRadius[k]=buttonRadius*.80f*clamp(prefs.getFloat("size_"+slot,1f),.6f,1.5f);
        }
        leftX=w*clamp(prefs.getFloat("x_20",.25f),.08f,.92f); leftY=h*clamp(prefs.getFloat("y_20",.81f),.12f,.88f);
        rightX=w*clamp(prefs.getFloat("x_21",.75f),.08f,.92f); rightY=h*clamp(prefs.getFloat("y_21",.81f),.12f,.88f);''')
    v=section(v,'    private boolean comboHit(', '    private Button hit(','''    private int comboHit(float x, float y) {
        for(int k=0;k<4;k++) if(comboEnabled[k] && Math.abs(x-comboX[k])<=comboRadius[k]*1.42f && Math.abs(y-comboY[k])<=comboRadius[k]*.94f)return 16+k;
        return -1;
    }

''')
    v=one(v,'bindings.reset(); // never leave ZL latched across focus/rotation/settings','bindings.reset();\n        removeCallbacks(timer);')
    v=one(v,'        send(0, 0, 0, 0, 0);\n        invalidate();','        TotkActivity.nativeTouchInput(-1L,0,0,0,0); // clear pending native edges too\n        stateSent=false;\n        send(0, 0, 0, 0, 0);\n        invalidate();')
    v=one(v,'        boolean macroHeld = false;','        removeCallbacks(timer);')
    v=one(v,'                macroHeld = true;','                bits |= 1L << p.slot;')
    v=one(v,'float rate = Math.min(1f, length / Math.max(stickRadius, 1f));','float rate = Math.min(1f, Math.max(0f,(length / Math.max(stickRadius, 1f)-deadzone)/(1f-deadzone))*sensitivity);')
    v=one(v,'long acceptedButtons = visible ? bindings.apply(bits, macroHeld) : 0;','long now=SystemClock.uptimeMillis();\n        long acceptedButtons = visible ? bindings.apply(bits, now) : 0;\n        long delay=bindings.nextDelay(now);\n        if(visible && delay>=0 && isAttachedToWindow()) postDelayed(timer,delay);')
    v=one(v,'bindings.toggledOnThisPress()','bindings.changed()')
    v=one(v,'        if (comboHit(x, y)) {\n            pointers.put(id, new Finger(MODE_MACRO, x, y));','        int shortcut=comboHit(x,y);\n        if (shortcut>=0) {\n            Finger f=new Finger(MODE_MACRO,x,y);f.slot=shortcut;pointers.put(id,f);')
    v=one(v,'int mode = x < getWidth() / 2f ? MODE_LEFT_STICK : MODE_RIGHT_STICK;\n        if (y > getHeight() * .60f && !stickOwned(mode)) {','''float dl=(float)Math.hypot(x-leftX,y-leftY),dr=(float)Math.hypot(x-rightX,y-rightY);
        int mode = dl < dr ? MODE_LEFT_STICK : MODE_RIGHT_STICK;
        if ((Math.min(dl,dr)<stickRadius*1.55f || y>getHeight()*.60f) && !stickOwned(mode)) {''')
    v=one(v,'        diagnostics.markTouch(); // sampling is independent of actual Switch button edges\n','')
    v=one(v,'        diagnostics.onAttached();\n','')
    v=one(v,'        diagnostics.onDetached();\n','')
    v=section(v,'    private void showSettings() {','    private static int nearest(',SETTINGS)
    v=section(v,'    private void drawCombo(Canvas canvas) {','    @Override protected void onDraw(',DRAW)
    v=one(v,'if (!proStyle || b.bit < LEFT || b.bit > DOWN) drawButton(canvas, b);','drawButton(canvas,b);')
    v=one(v,'            if (proStyle) drawProDpad(canvas);\n','') # independent directional positions
    v=one(v,'if (bindings.toggleZl() && bindings.latchedZl()) {','for(int slot=0;slot<16;slot++) if(bindings.latched(slot)) {')
    v=one(v,'Button b = buttons[ZL];','Button b = buttons[slot];')
    v=one(v,'        drawDebugPanel(canvas);\n','')
    changes[JAVA+'TouchControlsView.java']=v
    changes[JAVA+'TouchBindings.java']=(HERE/'TouchBindings.java').read_text()
    # Bring only the overlay lifecycle block across; do not overwrite fork activity.
    act=read(JAVA+'TotkActivity.java');prev=previous(JAVA+'TotkActivity.java')
    start=prev.index('    /**\n     * The AHB Vulkan presenter');end=prev.index('    /** Window-level fallback',start)
    block=prev[start:end].replace('!resumed || !hasWindowFocus() || updateOpen','!resumed || !hasWindowFocus() || updateOpen || gameMenuOpen')
    act=one(act,'import android.view.View;','import android.view.View;\nimport android.view.Gravity;\nimport android.graphics.PixelFormat;')
    act=one(act,'    private PresentationController companion;','    private PresentationController companion;\n    private TouchControlsView touchControls;\n    private boolean touchPanelAttached;')
    act=one(act,'    private static native void nativeGameInputFocus(boolean top);','    private static native void nativeGameInputFocus(boolean top);\n    static native void nativeTouchInput(long buttons, int lx, int ly, int rx, int ry);')
    act=one(act,'    private boolean settingsRequested;',block+'    private boolean settingsRequested;')
    act=one(act,'        updateOpen = true;','        updateOpen = true;\n        hideTouchPanel();')
    act=one(act,'            nativeGameFocus(hasWindowFocus(), single);','            nativeGameFocus(hasWindowFocus(), single);\n            scheduleTouchPanel();')
    act=one(act,'        gameMenuOpen = true;','        gameMenuOpen = true;\n        hideTouchPanel();')
    act=one(act,'            gameMenuOpen = false;\n            Log.w','            gameMenuOpen = false;\n            scheduleTouchPanel();\n            Log.w')
    act=one(act,'        if (resumed) ensureMainDisplay();','        if (resumed) { ensureMainDisplay(); hideTouchPanel(); scheduleTouchPanel(); }')
    act=one(act,'        gameMenuOpen = false;\n        applyFrameRateHint();','        gameMenuOpen = false;\n        scheduleTouchPanel();\n        applyFrameRateHint();')
    act=one(act,'        nativeGameInputFocus(top); // a release routed to another display must not leave a controller button held','        nativeGameInputFocus(top); // a release routed to another display must not leave a controller button held\n        if(top) scheduleTouchPanel(); else hideTouchPanel();')
    act=one(act,'        super.onWindowFocusChanged(focused);','        super.onWindowFocusChanged(focused);\n        if(focused) scheduleTouchPanel(); else hideTouchPanel();')
    act=one(act,'        resumed = false;\n        applyFrameRateHint();','        resumed = false;\n        hideTouchPanel();\n        applyFrameRateHint();')
    act=one(act,'        updatePresentPrerotate(0);\n        if (companion','        hideTouchPanel();\n        touchControls=null;\n        updatePresentPrerotate(0);\n        if (companion')
    changes[JAVA+'TotkActivity.java']=act
    c=read(RUNTIME+'frontend_android.c');oldc=previous(RUNTIME+'frontend_android.c');start=oldc.index('/* Touch input is independent');end=oldc.index('static overlay_chord g_chord;',start)
    bridge=oldc[start:end].replace('    g_touch_edges |= next & ~g_touch_buttons;', '    if (buttons == -1 || runtime_android_game_paused()) {\n        g_touch_buttons = g_touch_edges = 0; memset(g_touch_axes, 0, sizeof g_touch_axes);\n        g_pad_seen = 1; pthread_mutex_unlock(&g_pad_mu); return;\n    }\n    g_touch_edges |= next & ~g_touch_buttons;')
    c=one(c,'static int g_pad_seen;','static int g_pad_seen;\n'+bridge.rstrip())
    clear='    g_keys = g_hat = g_trig = g_edges = 0; memset(g_axes, 0, sizeof g_axes); memset(&g_chord, 0, sizeof g_chord);'
    c=one(c,clear,clear+'\n    g_touch_buttons = g_touch_edges = 0; memset(g_touch_axes, 0, sizeof g_touch_axes);')
    start=oldc.index('    out->buttons = g_keys | g_hat | g_trig | g_edges | g_touch_buttons');end=oldc.index('    out->connected = g_pad_seen;',start)
    c=section(c,'    out->buttons = g_keys | g_hat | g_trig | g_edges;', '    out->connected = g_pad_seen;',oldc[start:end]);changes[RUNTIME+'frontend_android.c']=c
    j=read(RUNTIME+'companion_jni.c');j=one(j,'            {"nativeGameInputFocus", "(Z)V", (void *)runtime_android_game_input_focus},','            {"nativeGameInputFocus", "(Z)V", (void *)runtime_android_game_input_focus},\n            {"nativeTouchInput", "(JIIII)V", (void *)runtime_android_touch_input},')
    j=one(j,'jint runtime_android_feedback_enabled(JNIEnv *env, jclass cls);','jint runtime_android_feedback_enabled(JNIEnv *env, jclass cls);\nvoid runtime_android_touch_input(JNIEnv *env, jclass cls, jlong buttons, jint lx, jint ly, jint rx, jint ry);')
    changes[RUNTIME+'companion_jni.c']=j
    changes['tests/touch_shortcuts/TouchBindingsProbe.java']=(HERE/'TouchBindingsProbe.java').read_text()
    for rel in changes: print(('Would update ' if a.check else 'Update ')+rel)
    if not a.check:
        for rel,content in changes.items():
            f=root/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(content)
    print('Source anchor validation passed. Android compilation/device testing still required.')
SETTINGS=r'''    private void showSettings() {
        resetInput();
        String[] items = {visible?"Hide controls":"Show controls", "Button behavior", "Custom combo buttons", "Position and individual size", "Control size", "Opacity", "Controller style", "Touch vibration", "Analog sensitivity", "Analog dead zone", "Layout profile: "+(profile+1), "Reset current profile"};
        new AlertDialog.Builder(activity).setTitle("Touch controller").setItems(items,(d,which)->{
            switch(which){
                case 0: visible=!visible; prefs.edit().putBoolean(KEY_VISIBLE,visible).apply(); break;
                case 1: chooseSlot(false,false); break;
                case 2: chooseSlot(true,false); break;
                case 3: chooseSlot(false,true); break;
                case 4: sliderDialog("Control size", "scale", scale,.75f,1.35f); break;
                case 5: sliderDialog("Opacity",KEY_ALPHA,opacity,.20f,.85f);break;
                case 6: proStyle=!proStyle; prefs.edit().putString(KEY_STYLE,proStyle?STYLE_PRO:STYLE_OUTLINE).apply();break;
                case 7: haptics=!haptics; prefs.edit().putBoolean(KEY_HAPTICS,haptics).apply();break;
                case 8: sliderDialog("Analog sensitivity","sensitivity",sensitivity,.5f,2f);break;
                case 9: sliderDialog("Analog dead zone","deadzone",deadzone,0f,.35f);break;
                case 10: new AlertDialog.Builder(activity).setTitle("Saved layout profiles").setSingleChoiceItems(new String[]{"Profile 1","Profile 2","Profile 3"},profile,(pd,i)->{resetInput(); profile=i;activity.getSharedPreferences(PREFS+"_profiles",Context.MODE_PRIVATE).edit().putInt("active",i).apply();loadProfile();layoutControls(getWidth(),getHeight());invalidate();pd.dismiss();}).setNegativeButton("Cancel",null).show();break;
                case 11: new AlertDialog.Builder(activity).setMessage("Reset this profile only?").setPositiveButton("Reset",(rd,i)->{resetInput();prefs.edit().clear().apply();loadProfile();layoutControls(getWidth(),getHeight());invalidate();}).setNegativeButton("Cancel",null).show();break;
            }
            invalidate();
        }).setNegativeButton("Close",null).show();
    }
    private void sliderDialog(String title,String key,float value,float lo,float hi){
        LinearLayout box=new LinearLayout(activity);box.setOrientation(LinearLayout.VERTICAL);box.setPadding((int)dp(20),0,(int)dp(20),0);
        SeekBar slider=addSlider(box,title,value,lo,hi);
        new AlertDialog.Builder(activity).setTitle(title).setView(box).setPositiveButton("Save",(d,i)->{resetInput();prefs.edit().putFloat(key,sliderValue(slider,lo,hi)).apply();loadProfile();layoutControls(getWidth(),getHeight());invalidate();}).setNegativeButton("Cancel",null).show();
    }
    private String slotName(int i){return i<16?ACTION_LABELS[i]:i<20?comboLabels[i-16]:i==20?"Left stick":"Right stick";}
    private void chooseSlot(boolean shortcuts,boolean layout){
        int start=shortcuts?16:0,end=layout?22:shortcuts?20:16;
        String[] names=new String[end-start];for(int i=start;i<end;i++)names[i-start]=slotName(i);
        new AlertDialog.Builder(activity).setTitle(layout?"Choose control":shortcuts?"Choose shortcut":"Choose button").setItems(names,(d,i)->{if(layout)editPosition(start+i);else editBinding(start+i);}).setNegativeButton("Cancel",null).show();
    }
    private SeekBar addSlider(LinearLayout box,String label,float value,float lo,float hi){
        TextView title=new TextView(activity);box.addView(title);
        SeekBar s=new SeekBar(activity);s.setMax(100);s.setProgress(Math.round((clamp(value,lo,hi)-lo)*100/(hi-lo)));box.addView(s);
        title.setText(label+": "+Math.round(sliderValue(s,lo,hi)*100)+"%");
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar bar,int p,boolean user){title.setText(label+": "+Math.round(sliderValue(bar,lo,hi)*100)+"%");}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
        return s;
    }
    private static float sliderValue(SeekBar b,float lo,float hi){return lo+(hi-lo)*b.getProgress()/100f;}
    private LinearLayout editor(){LinearLayout b=new LinearLayout(activity);b.setOrientation(LinearLayout.VERTICAL);b.setPadding((int)dp(20),(int)dp(8),(int)dp(20),(int)dp(8));return b;}
    private void editPosition(int slot){
        if(getWidth()<=0||getHeight()<=0)return;
        float x=slot<16?buttons[slot].x:slot<20?comboX[slot-16]:slot==20?leftX:rightX;
        float y=slot<16?buttons[slot].y:slot<20?comboY[slot-16]:slot==20?leftY:rightY;
        LinearLayout box=editor();SeekBar sx=addSlider(box,"Horizontal",x/getWidth(),.08f,.92f),sy=addSlider(box,"Vertical",y/getHeight(),.12f,.88f);
        SeekBar size=addSlider(box,"Size",prefs.getFloat("size_"+slot,1f),.6f,1.5f);
        if(slot>=20){size.setEnabled(false);TextView hint=new TextView(activity);hint.setText("Stick size follows global control size.");box.addView(hint);}
        new AlertDialog.Builder(activity).setTitle(slotName(slot)+" layout").setView(box).setPositiveButton("Save",(d,i)->{resetInput();prefs.edit().putFloat("x_"+slot,sliderValue(sx,.08f,.92f)).putFloat("y_"+slot,sliderValue(sy,.12f,.88f)).putFloat("size_"+slot,sliderValue(size,.6f,1.5f)).apply();layoutControls(getWidth(),getHeight());invalidate();}).setNegativeButton("Cancel",null).show();
    }
    private void editBinding(int slot){
        LinearLayout box=editor(); boolean shortcut=slot>=16;
        android.widget.CheckBox enabled=new android.widget.CheckBox(activity);enabled.setText("Show shortcut");
        EditText name=new EditText(activity);name.setSingleLine();name.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(12)});
        android.widget.CheckBox[] actions=new android.widget.CheckBox[16];
        if(shortcut){enabled.setChecked(comboEnabled[slot-16]);box.addView(enabled);name.setText(comboLabels[slot-16]);box.addView(name);}
        TextView title=new TextView(activity);title.setText("Activation mode");box.addView(title);
        Spinner modes=new Spinner(activity);ArrayAdapter<String> adapter=new ArrayAdapter<>(activity,android.R.layout.simple_spinner_dropdown_item,TouchBindings.MODES);modes.setAdapter(adapter);modes.setSelection(bindings.mode(slot));box.addView(modes);
        TextView timing=new TextView(activity);timing.setText("Timed press duration / turbo cycle (80–5000 ms)");box.addView(timing);
        EditText ms=new EditText(activity);ms.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);ms.setText(Integer.toString(bindings.duration(slot)));box.addView(ms);
        if(shortcut){for(int i=0;i<16;i++){actions[i]=new android.widget.CheckBox(activity);actions[i].setText(ACTION_LABELS[i]);actions[i].setChecked((bindings.mask(slot)&(1L<<i))!=0);box.addView(actions[i]);}}
        ScrollView scroll=new ScrollView(activity);scroll.addView(box);
        AlertDialog dialog=new AlertDialog.Builder(activity).setTitle(slotName(slot)+" binding").setView(scroll).setPositiveButton("Save",null).setNegativeButton("Cancel",null).create();
        dialog.setOnShowListener(ignored->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view->{
            int duration;try{duration=Integer.parseInt(ms.getText().toString());}catch(NumberFormatException ex){ms.setError("Enter milliseconds");return;}
            if(duration<80||duration>5000){ms.setError("80–5000 ms");return;}
            long mask=shortcut?0:1L<<slot;if(shortcut)for(int i=0;i<16;i++)if(actions[i].isChecked())mask|=1L<<i;
            if(shortcut&&enabled.isChecked()&&mask==0){android.widget.Toast.makeText(activity,"Select at least one input",android.widget.Toast.LENGTH_SHORT).show();return;}
            resetInput();int mode=modes.getSelectedItemPosition();bindings.configure(slot,mode,duration,mask);
            SharedPreferences.Editor e=prefs.edit().putInt("mode_"+slot,mode).putInt("duration_"+slot,duration).putLong("mask_"+slot,mask);
            if(shortcut){int k=slot-16;comboEnabled[k]=enabled.isChecked();String label=name.getText().toString().trim();comboLabels[k]=label.isEmpty()?"M"+(k+1):label;e.putBoolean("enabled_"+slot,comboEnabled[k]).putString("label_"+slot,comboLabels[k]);}
            e.apply();invalidate();dialog.dismiss();
        }));dialog.show();
    }

'''
DRAW=r'''    private void drawCombo(Canvas canvas) {
        if(!visible)return;
        for(int k=0;k<4;k++){
            if(!comboEnabled[k])continue;
            int slot=16+k;boolean down=bindings.active(slot);
            float x=comboX[k],y=comboY[k],r=comboRadius[k],hw=r*1.30f,hh=r*.73f;
            shape.set(x-hw,y-hh,x+hw,y+hh);
            fill(down?0xffb2c8db:0xff18232e,down?1.5f:1.17f);canvas.drawRoundRect(shape,hh,hh,paint);
            stroke(0xffe3ebf5,down?1.6f:1f,dp(1.4f));canvas.drawRoundRect(shape,hh,hh,paint);
            fill(down?0xff162431:Color.WHITE,1.65f);paint.setTypeface(CONTROL_FONT);paint.setTextAlign(Paint.Align.CENTER);paint.setTextSize(r*.65f);
            String label=comboLabels[k];float measured=paint.measureText(label);if(measured>hw*1.8f)paint.setTextSize(paint.getTextSize()*hw*1.8f/measured);
            canvas.drawText(label,x,y-(paint.ascent()+paint.descent())/2f,paint);
            if(bindings.latched(slot)){fill(Color.WHITE,1.5f);paint.setTextSize(dp(9));canvas.drawText("LOCK",x,y-hh-dp(4),paint);}
        }
    }

'''
if __name__=='__main__':
    try: main()
    except (ValueError, OSError, subprocess.CalledProcessError) as e:
        sys.exit('ABORT: '+str(e))
