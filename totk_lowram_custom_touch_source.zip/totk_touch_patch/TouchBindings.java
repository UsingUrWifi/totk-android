package com.aure.totk;

/** UI-thread input state. Slots 0..15 are Switch inputs; slots 16..19 are shortcuts. */
final class TouchBindings {
    static final int COUNT=20, HOLD=0, TOGGLE=1, TIMED=2, TURBO=3;
    static final String[] MODES={"Hold","Toggle","Timed press","Turbo"};
    static final long NATIVE_MASK=0xffffL;
    private final int[] mode=new int[COUNT], duration=new int[COUNT];
    private final long[] mask=new long[COUNT], since=new long[COUNT];
    private long previous, latched, timed, active, changed;
    TouchBindings(){ for(int i=0;i<COUNT;i++){mask[i]=i<16?1L<<i:0;duration[i]=250;} }
    void configure(int i,int m,int ms,long bits){
        if(i<0||i>=COUNT||m<0||m>3||ms<80||ms>5000||(bits&~NATIVE_MASK)!=0)throw new IllegalArgumentException();
        reset(); mode[i]=m; duration[i]=ms; mask[i]=i<16?1L<<i:bits;
    }
    int mode(int i){return mode[i];} int duration(int i){return duration[i];} long mask(int i){return mask[i];}
    boolean active(int i){return (active&(1L<<i))!=0;} boolean latched(int i){return (latched&(1L<<i))!=0;}
    boolean changed(){return changed!=0;}
    void reset(){previous=latched=timed=active=changed=0;}
    long apply(long raw,long now){
        raw&=(1L<<COUNT)-1; long rising=raw&~previous; changed=0; active=0; long result=0;
        for(int i=0;i<COUNT;i++){
            long b=1L<<i; boolean press=(rising&b)!=0, held=(raw&b)!=0, on=false;
            if(press)since[i]=now;
            switch(mode[i]){
                case HOLD: on=held; break;
                case TOGGLE: if(press){latched^=b;changed|=b;} on=(latched&b)!=0;break;
                case TIMED: if(press)timed|=b; if(now-since[i]>=duration[i])timed&=~b;on=(timed&b)!=0;break;
                case TURBO: on=held && (now-since[i])%duration[i]<duration[i]/2;break;
            }
            if(on){active|=b;result|=mask[i];}
        }
        previous=raw;return result;
    }
    long nextDelay(long now){
        long delay=Long.MAX_VALUE;
        for(int i=0;i<COUNT;i++){
            long b=1L<<i;
            if(mode[i]==TIMED&&(timed&b)!=0)delay=Math.min(delay,duration[i]-(now-since[i]));
            if(mode[i]==TURBO&&(previous&b)!=0){long phase=(now-since[i])%duration[i];long half=duration[i]/2;delay=Math.min(delay,phase<half?half-phase:duration[i]-phase);}
        }
        return delay==Long.MAX_VALUE?-1:Math.max(1,delay);
    }
}
